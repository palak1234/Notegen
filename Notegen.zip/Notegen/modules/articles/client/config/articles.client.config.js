'use strict';

// Configuring the Articles module
angular.module('articles').run(['Menus',
  function (Menus) {

  }
]);
